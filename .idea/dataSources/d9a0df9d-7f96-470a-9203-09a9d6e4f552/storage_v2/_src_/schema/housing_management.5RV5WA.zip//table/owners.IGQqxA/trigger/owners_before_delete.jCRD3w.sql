create definer = `Housing Management`@`%` trigger owners_BEFORE_DELETE
    before delete
    on owners
    for each row
BEGIN
    DELETE FROM properties;
END;

